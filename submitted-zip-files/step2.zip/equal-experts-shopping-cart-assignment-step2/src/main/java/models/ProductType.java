package models;

public enum ProductType {
    SOAP
}
