package models;

public enum TaxType {
    SALES
}
